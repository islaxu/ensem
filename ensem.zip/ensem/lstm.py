import torch  
import torch.optim as optim   
import numpy as np  
import os
import pickle
import pandas as pd
from tqdm import tqdm
from src.models import OmniAnomaly, LSTM, LSTMModel
from src.constants import *
from src.plotting import *
from src.pot import *
from src.utils import *
from src.diagnosis import *
from src.merlin import *
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torch.nn as nn
from time import time
from pprint import pprint
# 数据预处理，这里我们假设已经将数据分为训练集和测试集  
# train_data, test_data 是 numpy 数组  
# train_labels 是训练集对应的标签（0 表示正常，1 表示异常）

dataset="try"  
def load_dataset_l(dataset):  
    folder = os.path.join(output_folder1, dataset)  
    if not os.path.exists(folder):  
        raise Exception('Processed Data not found.')  
    loader = []  
    for file in ['train', 'train_labels', 'test', 'test_labels']:  
        if dataset == 'try': file = '11_' + file  
        loader.append(np.load(os.path.join(folder, f'{file}.npy')))       
    train_data, train_labels, test_data, test_labels = loader  
  
    # 添加序列长度维度  
    train_data = np.expand_dims(train_data, axis=1)  
    test_data = np.expand_dims(test_data, axis=1)  
  
    train_dataset = TensorDataset(torch.tensor(train_data), torch.tensor(train_labels))    
    test_dataset = TensorDataset(torch.tensor(test_data), torch.tensor(test_labels))    
    train_loader = DataLoader(train_dataset, batch_size=train_data.shape[0])    
    test_loader = DataLoader(test_dataset, batch_size=test_data.shape[0])    
    return train_loader, test_loader  


def save_model_l(model, optimizer, scheduler, epoch, accuracy_list):
	folder = 'checkpoints/ensem_LSTM_try/'
	os.makedirs(folder, exist_ok=True)
	file_path = f'{folder}/model.ckpt'
	torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'accuracy_list': accuracy_list}, file_path)
def load_model_l(model_class, dims):
	import src.models 
	model_class = getattr(src.models, "LSTM")
	model = model_class(dims).double()
	optimizer = torch.optim.AdamW(model.parameters() , lr=model.lr, weight_decay=1e-5)
	scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 5, 0.9)
	fname = 'checkpoints/ensem_LSTM_try/model.ckpt'
	if os.path.exists(fname) and (not args.retrain or args.test):
		print(f"{color.GREEN}Loading pre-trained model: LSTM")
		checkpoint = torch.load(fname)
		model.load_state_dict(checkpoint['model_state_dict'])
		optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
		scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
		epoch = checkpoint['epoch']
		accuracy_list = checkpoint['accuracy_list']
	else:
		print(f"{color.GREEN}Creating new model: {model.name}{color.ENDC}")
		epoch = -1; accuracy_list = []
	return model, optimizer, scheduler, epoch, accuracy_list  
 
def train_LSTM(model, train_loader, epochs):  
    criterion = nn.BCELoss()  
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    model.train()   
    for epoch in range(epochs):   
        for data, labels in train_loader:  
            labels = labels.float()  
            optimizer.zero_grad()  
            outputs = model(data.float())  
            loss = criterion(outputs.squeeze(), labels.squeeze())  
            loss.backward()  
            optimizer.step()
    print("1:",outputs) 
    
  
# 分别训练基本模型 
if __name__ == '__main__':   
    train_loader, test_loader = load_dataset_l(dataset) 
    #trainD, testD = next(iter(train_loader)), next(iter(test_loader))
    # Initialize the model  
    input_size = 7  
    hidden_size = 128  
    output_size = 7  
    model = LSTMModel(input_size, hidden_size, output_size)  

    # Train the model  
    epochs = 1
    train_LSTM(model, train_loader, epochs=1)
    #Evaluate the model on the test dataset
    #model.eval()
    #   
    with torch.no_grad():  
        total = 0  
        correct = 0  
        all_outputs = []  
        all_labels = []  
        for batch_data, batch_labels in test_loader:  
            print(batch_data)
            batch_labels = batch_labels.float()  
            outputs = model(batch_data.float())  
            predicted = (outputs > 0.5).float()  
            total += batch_labels.size(0)  
            correct += (predicted == batch_labels).sum().item()  
            all_outputs.append(predicted.numpy())  
            all_labels.append(batch_labels.numpy())  
        print("2:",outputs,outputs.shape)
        all_outputs = np.vstack(all_outputs)
        print("3:",all_outputs,all_outputs.shape)  
        all_labels = np.vstack(all_labels)  
        accuracy = correct / total  
        precision, recall, f1, _ = precision_recall_fscore_support(all_labels, all_outputs, average='weighted')  
        print(f'Epoch {epoch+1}, Accuracy: {accuracy:.2f}, Precision: {precision:.2f}, Recall: {recall:.2f}, F1: {f1:.2f}')       
