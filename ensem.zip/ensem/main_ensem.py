import torch  
import torch.optim as optim   
import numpy as np  
import os
import pickle
import pandas as pd
from tqdm import tqdm
from src.models import OmniAnomaly, LSTMModel
from src.constants import *
from src.plotting import *
from src.pot import *
from src.utils import *
from src.diagnosis import *
from src.merlin import *
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torch.nn as nn
from time import time
from pprint import pprint
from lstm import train_LSTM,load_dataset_l,save_model_l,load_model_l
from omni import train_omni,backprop,load_dataset_o,save_model_o,load_model_o
from sklearn.metrics import precision_recall_fscore_support  
# 数据预处理，这里我们假设已经将数据分为训练集和测试集  
# train_data, test_data 是 numpy 数组  
# train_labels 是训练集对应的标签（0 表示正常，1 表示异常）  

dataset="try"
epochs=1
import numpy as np  
import torch  
from torch.utils.data import DataLoader, TensorDataset  
from sklearn.metrics import precision_recall_fscore_support  

# OmniAnomaly的数据
lstm_model = LSTMModel(7,128,7)

print('------------Training LSTM-----------------') 
train_loader_l, test_loader_l = load_dataset_l(dataset)
lstm_model = LSTMModel(7,128,7)  
''' 
train_LSTM(lstm_model, train_loader_l,test_loader, epochs)  
torch.save(lstm_model.state_dict(), 'lstm_model.pth')  
'''
print('------------Training Omnianomaly-----------------')
train_loader_o, test_loader, labels = load_dataset_o(dataset) 
#print(labels)
dims=labels.shape[1]
#print(dims)
trainD, testD = next(iter(train_loader_o)), next(iter(test_loader))
trainO, testO = trainD, testD
'''
model, optimizer, scheduler, epoch, accuracy_list = load_model_o(OmniAnomaly, dims)
num_epochs = 1; e = epoch + 1; start = time() 
train_omni(OmniAnomaly,trainD,trainO,dims,num_epochs=1, start = time()) # file_path = f'{folder}/model.ckpt'
#model.save('omni_anomaly_model.pth') 
'''
# 集成模型  
class EnsembleModel:  
    def __init__(self, model1, model2):  
        self.model1 = model1  
        self.model2 = model2
	
    def predict(self, data1,data2):  
        #prediction1 = self.model1(data1)
        for batch_data, batch_labels in data1:  
            prediction1 = self.model1(batch_data.float())   
        prediction2 = self.model2(data2)
        ensemble_prediction = (prediction1 + prediction2) / 2  
        return ensemble_prediction  

# 加载训练好的基模型  
lstm_model.load_state_dict(torch.load('lstm_model.pth'))   
model, optimizer, scheduler, epoch, accuracy_list = load_model_o(OmniAnomaly, dims) 
# 创建并使用集成模型进行异常检测
def load_detec_dataset(dataset):
	folder = os.path.join(output_folder, dataset)
	if not os.path.exists(folder):
		raise Exception('Processed Data not found.')
	loader = []
	for file in ['test', 'labels']:
		if dataset == 'try': file = '11_' + file
		loader.append(np.load(os.path.join(folder, f'{file}.npy')))
	test_data, labels = loader  
	test_dataset = TensorDataset(torch.tensor(test_data), torch.tensor(labels))
	test_loader = DataLoader(test_dataset, batch_size=64)    
	return test_loader
  
detect_loader=load_detec_dataset(dataset)
ensemble_model = EnsembleModel(lstm_model, model)  
print(ensemble_model) 

ensemble_model.predict(test_loader_l,test_loader)  
with torch.no_grad():  
    for test_data, labels in test_loader:  
        # 假设数据已经具有适合 LSTM 输入的形状  
        outputs = ensemble_model(test_data)  
'''
total = 0  
correct = 0  
all_outputs = []  
all_labels = []  
for batch_data, batch_labels in test_loader:  
	batch_labels = batch_labels.float()  
	outputs = model(batch_data.float())  
	predicted = (outputs > 0.5).float()  
	total += batch_labels.size(0)  
	correct += (predicted == batch_labels).sum().item()  
	all_outputs.append(predicted.numpy())  
	all_labels.append(batch_labels.numpy())  

all_outputs = np.vstack(all_outputs)  
all_labels = np.vstack(all_labels)  
accuracy = correct / total  
precision, recall, f1, _ = precision_recall_fscore_support(all_labels, all_outputs, average='weighted')  
print(f'Epoch {epoch+1}, Accuracy: {accuracy:.2f}, Precision: {precision:.2f}, Recall: {recall:.2f}, F1: {f1:.2f}')     
  

for batch_data, batch_labels in detect_loader:
    print(batch_data,batch_labels)  
    #batch_outputs = ensemble_model.predict(batch_data.float())
    batch_outputs = ensemble_model.predict(test_loader_l,test_loader)
    predicted = (batch_outputs > 0.5).float()  
    all_outputs.append(predicted.numpy())  
    all_labels.append(batch_labels.numpy())  
  
all_outputs = np.vstack(all_outputs)  
all_labels = np.vstack(all_labels)  
  
# 输出评价指标  
precision, recall, f1, _ = precision_recall_fscore_support(all_labels, all_outputs, average='weighted')  
print(f'Precision: {precision:.2f}, Recall: {recall:.2f}, F1: {f1:.2f}')  
''' 