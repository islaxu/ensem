import pandas as pd
import numpy as np
import os
from src.folderconstants import *

file_path = '/home/v-xujiaying/ensem/processed/try/11_train.npy' 
data = np.load(file_path) 

d1=(data.shape)

def generate_random_array(shape):   
    values = [0, 1]  
    probabilities = [0.95, 0.05]  
    random_array = np.random.choice(values, size=shape, p=probabilities)  
    return random_array 

d2=generate_random_array(d1)
print(d2,d2.shape)
np.save(os.path.join(output_folder1, f"11_train_labels.npy"), d2)